<?php
/**
 * Audiobook Controller.
 */
namespace Controller;

use Silex\Application;
use Silex\Api\ControllerProviderInterface;

class AudiobookController implements ControllerProviderInterface
{
    /**
     * {@inheritdoc}
     */
    public function connect(Application $app)
    {
        $controller = $app['controllers_factory'];
        $controller->get('/', [$this, 'indexAction'])->bind('audiobook_index');

        return $controller;
    }
}