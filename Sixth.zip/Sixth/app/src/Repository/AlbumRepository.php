<?php
/**
 * Albums Repository.
 */

use Doctrine\DBAL\Connection;
//use Utils\Paginator;

class AlbumRepository
{
    /**
     * Number of items per page.
     *
     * const int NUM_ITEMS
     */
    const NUM_ITEMS = 15;
    /**
     * Doctrine DBAL connection.
     *
     * @var \Doctrine\DBAL\Connection $db
     */
    protected $db;

    /**
     * AlbumRepository constructor.
     *
     * @param \Doctrine\DBAL\Connection $db
     */
    public function __construct(Connection $db)
    {
        $this->db = $db;
    }

    /**
     * Fetch all records.
     *
     * @return array Result
     */
    public function findAll($table)
    {
        $queryBuilder = $this->queryAll($table);

        return $queryBuilder->execute()->fetchAll();
    }

    /**
     * Query all records.
     *
     * @return \Doctrine\DBAL\Query\QueryBuilder Result
     */
    protected function queryAll($albums)
    {
        $queryBuilder = $this->db->createQueryBuilder();

        return $queryBuilder->select('a.artist', 'a.title', 'a.year')
            ->from('albums', 'a')
            ->setParameter(':comp', $albums, \PDO::PARAM_STR);
    }
}